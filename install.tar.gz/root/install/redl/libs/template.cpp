/*

//-----------------------------
// This is a template library
// for developers only 
//-----------------------------


	if((libs.find("TEMPLATE", 0) + 1)) {   //   <- NAME LIBS (HERE 'TEMPLATE')
						

		//HERE WRITE YOUR CODE
							
		if(codest0[0] == 't')	 {
			if(codest0[1] == 'e') {
				if(codest0[2] == 's') {
					if(codest0[3] == 't') {
												
						out << "cout << \"Hello, world!\" << endl;" << '\n'; //   <--- C++ code 
										
					}
				}
			}
		}
	
	
	}
*/

//---------------------------------
//		Now with the code


// libs TEMPLATE;
// test


// We will get -> Hello, world!
//---------------------------------

						
