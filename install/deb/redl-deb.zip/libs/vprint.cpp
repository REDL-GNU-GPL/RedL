

//-----------------------------
// Official lib
//-----------------------------
	
	if((libs.find("vprint", 0) + 1)) { 
			
			#include "../bin/vprint/io/io.cpp"
		
			#include "../bin/vprint/cmd/cmd.cpp"
			#include "../bin/vprint/voice/voice.cpp"
			#include "../bin/vprint/if/if.cpp"
			#include "../bin/vprint/for/for.cpp"
			#include "../bin/vprint/while/while.cpp"
			#include "../bin/vprint/while/do.cpp"
			#include "../bin/vprint/cin/cin.cpp"
			
			#include "../bin/vprint/var/string.cpp"
			#include "../bin/vprint/var/int.cpp"
			#include "../bin/vprint/var/float.cpp"
			#include "../bin/vprint/var/bool.cpp"
			#include "../bin/vprint/var/mass.cpp"
			
			#include "../bin/vprint/switch/switch.cpp"
			
			#include "../bin/vprint/oper/oper.cpp"
			
			#include "../bin/vprint/strint/comint.cpp"
			#include "../bin/vprint/strint/comstr.cpp"
	
	
	}
